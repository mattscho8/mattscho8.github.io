data{
  for(h in 1:ns){
    alpha[h] <- 1
  }
}

model{
  for(i in 1:m){
    w[i] ~ dbern(pw)    
  }
  lambda<-sum(w[])
  
  for(i in 1:m) {
    for(j in 1:until[i]){
      # DEATH
      ad[i,j] ~ dbern(piad[i,j])      
      # BIRTH
      ab[i,j] ~ dbern(piab[i,j])
      # ALIVE
      a[i,j] <- ab[i,j]*ad[i,j]*w[i]    
      a2[i,j] <- a[i,j]*(z[i,j]-1)  
      # CAPTURE
      x[i,j] ~ dbern(pcap[i,j])
      pcap[i,j]<-a[i,j]*p[i,j]      
    }
    
    z[i,1] ~ dcat(zp[1:ns]) 
    for(j in 2:until[i]){
      # MODEL FOR COVARIATE
#       z[i,j] ~ dcat(psi[z[i,j-1],1:ns]) 
      z[i,j] ~ dcat(pz[i,j,1:ns])
      for(h in 1:ns){
        pz[i,j,h] <- a[i,j-1]*psi[z[i,j-1],h] + (1-a[i,j-1])*zp[h]
      }  
    }

    # Prob for birth
    piab[i,1] <- zeta[1]
    sazero[i,1] <- 1
    for(j in 2:until[i]){
      piab[i,j] <- sazero[i,j]*zeta[j] + (1-sazero[i,j]) # sazero takes into account whether or not born before
      sazero[i,j] <- sazero[i,j-1]*(1-ab[i,j-1])
    }
    
    # Prob for death
    piad[i,1] <- 1
    for(j in 2:until[i]){
      piad[i,j] <-   ad[i,j-1]*(ab[i,j-1]*surv[i,j-1] + (1-ab[i,j-1]))
    }

    for(j in 1:until[i]-1){
      surv[i,j] <- sv[z[i,j],j]
    }
    for(j in 1:until[i]){
      p[i,j] <- pee[z[i,j],j]
    }
  }
    
  for(j in 1:(k-1)){
    logit(sv[1,j]) <- beta[1] + etas[j] # non-diseased group
    logit(sv[2,j]) <- beta[1] + beta[2] + etas[j]
  }
  
  for(j in 1:k){
    logit(pee[1,j]) <- gamma[1] + etap[j]
    logit(pee[2,j]) <- gamma[1] + gamma[2] + etap[j]            
  }

  for(h in 1:2){
    beta[h] ~ dt(0,0.16,3) # sigma of 2.5 of
    gamma[h] ~ dt(0,0.16,3)
    tau[h] <- 1/sd[h]/sd[h]
    sd[h] ~ dt(0,0.04,3)T(0,)
  }
  
  for(j in 1:k-1){
    etas[j] ~ dnorm(0,tau[1])
  }

  for(j in 1:k){
    etap[j] ~ dnorm(0,tau[2])
  }
  
  for(h in 1:ns){
    psi[h,1:ns] ~ ddirch(alpha[])
  }
  zp[1:ns] ~ ddirch(alpha[])

  for(j in 1:k-1){
    zeta[j] ~ dbeta(1,uppz[j])
    uppz[j] <- k-j
  }  
  zeta[k] <- 1
  
  pw ~ dbeta(1,1)
  
  for(j in 1:k){
    N[j]<-sum(a[1:m,j])
    Nd[j] <- sum(a2[1:m,j])
  }

}
