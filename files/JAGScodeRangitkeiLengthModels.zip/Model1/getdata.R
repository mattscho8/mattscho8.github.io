# This script loads in the raw data from a table and creates the variables needed for analysis

# Now load the length data.  Assumed to be in the form of delimited text file with three columns:
# 1. Date of capture
# 2. Index of the individual caught
# 3. Length at capture
data=read.table("data.txt",header=T)
m=dim(data)[1] # number of recorded lengths
ind=data$Ind
y=data$Len
uid=unique(ind) # unique identities
n=length(uid)

# now load some additional data used in the analysis reported in the paper:
# 1. Sex of each individual (n x 1) vector
# 2. Season associated with each sample
sex=c(0, 0, NA, 0, NA, 0, NA, NA, 1, 0, NA, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, NA, NA, 1, 0, NA, NA, NA, 0, NA, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, NA, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1)
sea=c(0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0)

# now create additional variables for jags
# 1.  Find the sample occasion of the first capture for each individual
# 2.  At the same time compute delta
sampledates=as.numeric(as.Date(c("1993-03-01","1993-10-01","1994-03-01","1994-10-01","1995-03-01","1995-10-01","1996-03-01","1996-10-01", "1997-03-01","1997-10-01","1998-03-01","1998-10-01","1999-03-01","1999-10-01")))
samp=rep(NA,max(uid))
del=rep(NA,m)
for(i in uid)
{   captures=which(data$Ind==uid[i])
    dates=as.numeric(as.Date(data$Dat[captures]))
    firstcap=min(dates)
    samp[i]=max(which(firstcap>=sampledates))
    del[captures]=(dates-firstcap)/365
}
rm("data","i","captures","dates","firstcap","sampledates","uid") # clean up before continuing with analysis
