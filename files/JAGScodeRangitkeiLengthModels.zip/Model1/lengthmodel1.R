library(R2jags)

setwd('MYDIRECTORY/Model1')

# Load the data
source('getdata.R')

# create initial values
inits=function(){list("sdalp"=rgamma(1,1,1),"alpha"=rnorm(3,0,2),"mat"=rbinom(n,1,0.5),"pim"=rbeta(1,4,4),"xi"=rnorm(1,0,1),"mubeta"=rnorm(2,c(630,0),c(10,10)),"sdbeta"=rgamma(1,1,1),"mugamma"=rnorm(2,1,0),"taugamma"=dgamma(1,1,1),"psi"=rbeta(1,2,2))}

# create data and parameter lists
data=c('del','ind','m','n','samp','sea','sex','y')
params=c("alpha", "sdalp", "mubeta", "sdbeta", "mugamma", "sdgamma", "sdz", "psi", "pim")

# run the model in jags
jagsfit=jags(data=data, inits=inits,params,n.iter=500000, model.file="jagmod1m.txt")

save.image('model1.Rdata') # Save data for subsequent loading if needed

jagsfit.mcmc=as.mcmc(jagsfit)
traceplot(jagsfit.mcmc)
gelman.diag(jagsfit.mcmc)
summary(jagsfit.mcmc)  # summary statistics

# Now extract the output
coda=as.matrix(jagsfit.mcmc)
alpha=coda[,1:3]
deviance=coda[,4]
mubeta=coda[,5:6]
mugamma=coda[,7:8]
pim=coda[,9]
psi=coda[,10]
sdalp=coda[,11]
sdbeta=coda[,12]
sdgamma=coda[,13]
sdz=coda[,14]


# Produces one plot - add others as desired
plt=0
if(plt)postscript(file="betaL0.eps",horizontal=FALSE,onefile = FALSE,width=10,height=7.5) # Opens the file for printing
  hist(mubeta[,1],breaks=50,xlab="",ylab="",main="",bty="n",axes=0,lwd=2)
  axis(1,cex.lab=2)
  title(xlab=expression(beta[L0]),cex.lab=2)
if(plt)dev.off()

