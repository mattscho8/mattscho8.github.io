1.  The folder Model 1 contains R scripts for fitting the length-at-age (AFC) model

2.  The folder Model 2 contains R scripts for fitting the incremental (LFC) model

3.  Both folders contain identical scripts for the data which are in a file called "data.txt".  The data must be in a delimited (space, comma or tab) file with three columns:
	
	Column 1: Date (Y-m-d)
	Column 2: Individual (unique identifier)
	Column 3: Length at capture

	Note that there will be one row for each distinct capture of a fish including recaptures.

4. To fit the model JAGS must be installed.  All models have been fitted with JAGS-2.0 or later.  The R2jags package must also have been installed in R.

5. Model x is fitted by running the script lengthmodelx.R

