#' Butterfly Capture Counts
#'
#' A vector of how many times individual butterflies were captured in continuous time.
#'
#' @format A numeric vector of length 333 (i.e. n=333).
#'
#' @source Craig, C. C. (1953), "On the utilization of marked specimens in estimating populations of flying insects", Biometrika, 40, 170-176.
"cbutterfly"
