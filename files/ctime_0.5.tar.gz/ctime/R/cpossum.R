#' Catlins Possum Counts
#'
#' A vector of how many times individual brushtail possums were observed through
#' fecal pellets in the Catlins, New Zealand.
#'
#' @format A numeric vector of length 128 (i.e. n=128).
#'
#' @seealso \code{\link{ypossum}}
#'
#' @source Wright, J. A. (2011), "Incorporating Genotype Uncertainty Into Mark-recapture-type Models For Estimating Abundance Using DNA Samples," Ph.D. thesis, University of Otago.
"cpossum"
