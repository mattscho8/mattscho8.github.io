#' Convert Observations to Counts
#'
#' A utility function that converts a vector of observations \code{y} into a
#' vector of counts \code{c}. Note that the functions \code{\link{fitMt}} and
#' \code{\link{fitMh}} take \code{c} vectors as arguments.
#'
#' @param y A vector of observations i.e. which individual was observed in each
#'   sample.
#' @return Returns a vector of counts i.e. how many times each individual was
#'   observed. The vector is in decreasing order.
#'
#' @seealso \code{\link{fitMt}} \code{\link{fitMh}}
#'
#' @examples
#' y = sample(1:30, 50, replace=T)
#' c = y2c(y)
#' head(fitMh(c))
#'
#' @export
y2c = function(y){
  yu = unique(y)
  n = length(yu)
  c = rep(NA,n)
  for(i in 1:n){
    c[i] = sum(y==yu[i])
  }
  return(sort(c, decreasing=T))
}
