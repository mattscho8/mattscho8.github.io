
#' Test for Heterogeneity
#'
#' Undertakes the first model adequacy test proposed in the paper. It is a
#' posterior predictive assessment that tests for heterogeneity by measuring
#' whether the observed variability in counts is higher than would be expected
#' under homogeneity. A failed test indicates that model Mh might be
#' appropriate.
#'
#' @param Npost The posterior distribution for the true number of individuals
#'   \code{N} in the population, as an mx2 matrix. The second column lists
#'   potential values of \code{N} and the first column gives the corresponding
#'   densities. This will usually be output from \code{\link{directMt}}.
#' @param cobs The vector of counts i.e. how many times each individual was
#'   observed. This should exclude zeroes.
#' @param nsamp The number of replicate count vectors to sample. Each replicate
#'   count vector produces a test statistic; the more test statistics, the more
#'   reliable the test.
#'
#' @return Returns a list of length 3. The first entry is a scalar p-value for
#'   the data under model Mt. If this value is sufficiently small, a
#'   heterogeneous model should be considered. The second entry is the test
#'   statistic for the observed data, and the third entry is the vector of test
#'   statistics for the replicates.
#'
#' @seealso \code{\link{beh.test}} \code{\link{fitMh}}
#'
#' @examples
#' data(cimmigrant, package="ctime")  # Netherlands illegal immigrant counts (included in package)
#' result = directMt(cimmigrant)
#' test = het.test(result$Posterior, cimmigrant)
#' test$p.value    # p close to zero, indicating heterogeneity
#' hist(test$W.rep,(min(test$W.rep)-0.5):(test$W.obs+0.5),xlim = range(c(test$W.rep,test$W.obs)))
#' points(test$W.obs, 0, pch=4, lwd=5, cex=3, col="red")
#'
#' @export
het.test = function(Npost, cobs, nsamp = 5000){
  t = sum(cobs); nobs = length(cobs)
  Nuse = sample(Npost[,2], nsamp, replace=TRUE, prob=Npost[,1])  # sample from the posterior for N nsamp time

  Wobs = Wrep = rep(NA,nsamp)
  pb = txtProgressBar(min = 1, max = nsamp, initial = 1, char = '+', style = 3)

  for(i in 1:nsamp){
    tmp = sample(1:Nuse[i], t, replace=TRUE) # randomly sample a y vector given N
    cbar = t/Nuse[i]
    crep = tabulate(tmp, Nuse[i])  # convert y vector into c vector (with zeroes)
    Wrep[i] = sum((crep-cbar)^2)

    if(Nuse[i] > nobs){
      cobs0 = c(cobs, rep(0, Nuse[i]-nobs))  # append zeroes so that length(cobs)=N
    } else { cobs0 = cobs }
    Wobs[i] = sum((cobs0-cbar)^2)

    setTxtProgressBar(pb, i)
  }

  pval_het = mean(Wrep>Wobs)
  return(list("p.value"=pval_het, "W.obs"=Wobs, "W.rep"=Wrep))
}
