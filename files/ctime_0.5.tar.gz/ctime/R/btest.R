getytest = function(y,tee,K){
  cnt = 0
  for(i in 1:(tee-K)){
    tmp = sum(y[(i+1):(i+K)]==y[i])>0
    cnt = cnt + tmp
  }
  return(cnt)
}

gety = function(cee,nsamp,K=5){
  tee = sum(cee)
  n = length(cee)
  yvec = rep(1:n,times=cee)
  store = matrix(NA,nsamp,tee)
  repcnt = rep(0,nsamp)
  pb = txtProgressBar(min = 1, max = nsamp, initial = 1, char = '+', style = 3)
  for(j in 1:nsamp){
    y = sample(yvec,tee,replace=FALSE)
    store[j,] = y
    ## Evaluate the test statistic
    repcnt[j] = getytest(y,tee,K)
    setTxtProgressBar(pb, j)
  }
  return(repcnt)
}

#' Test for Behaviour Effects
#'
#' Undertakes the second model adequacy test proposed in the paper. It is a
#' permutation test, inspired by runs tests. This test measures whether
#' capturing an animal affects the probability of that animal being recaptured
#' in the following k captures. A failed test indicates that model Mb might be
#' appropriate.
#'
#' @param yobs The vector of observations - i.e. the order in which the
#'   individuals were observed.
#' @param k The number of subsequent captures to consider. For example, if k=1,
#'   we are only checking whether we capture the same individual twice in a row
#'   (which closely resembles a runs test).
#' @param nsamp The number of replicate observation vectors to sample. Each replicate
#'   observation vector produces a test statistic; the more test statistics, the more
#'   reliable the test.
#'
#' @return Returns a list of length 3. The first entry is a scalar
#'   p-value for the data under model Mt. If this value is sufficiently small,
#'   a behaviour effects model (see \code{\link{fitMb}}) should be considered.
#'   The second entry is the test statistic for the observed data, and the third
#'   entry is the vector of test statistics for the replicates.
#'
#' @seealso \code{\link{het.test}} \code{\link{fitMb}}
#'
#' @examples
#' data(ypossum, package="ctime")  # Catlins possum data, included in the package
#' test = beh.test(ypossum)
#' test$P.Value    # p<0.001, strong evidence of behaviour effects
#' hist(test$T_rep,(min(test$T_rep)-0.5):(max(test$T_rep)+0.5),xlim = range(c(test$T_rep,test$T_obs)))
#' points(test$T_obs, 0, pch=4, lwd=5, cex=3, col="red")
#'
#' @export
beh.test = function(yobs, k = 5, nsamp = 10000){
  cobs = y2c(yobs)
  Trep = gety(cobs,nsamp,k)
  t = sum(cobs)
  Tobs = getytest(yobs,t,k)
  pval_beh = mean(Trep>Tobs)
  return(list(P.Value=pval_beh, T_obs=Tobs, T_rep=Trep))
}

