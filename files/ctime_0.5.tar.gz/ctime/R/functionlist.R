#' The ctime Package
#'
#' This package works with capture-recapture data collected in continuous (or
#' near-continuous) time. The capture times are assumed to be realisations of
#' Poisson processes. Then Gibbs sampling can be used to find posterior
#' estimates to the true number of individuals \code{N} in the population. This
#' package features has support for three models. Mt assumes equal capture
#' probabilities for all individuals. Mh is a heterogeneous model, allowing
#' capture probabilities to vary between individuals according to a parametric
#' model. Mb is a behavioural model, under which the capture probability for an
#' individual depends on whether it has been caught before.
#'
#' Under Mt, we can also find the posterior for \code{N} analytically, which is
#' usually preferred to the Gibbs sampling approach. Also present in the package
#' are two proposed model adequacy tests, which test for heterogeneity and
#' behaviour effects respectively.
#'
#' @section Functions: \code{\link{fitMt}} \code{\link{fitMh}}
#'   \code{\link{fitMb}} \code{\link{directMt}} \code{\link{y2c}}
#'   \code{\link{het.test}} \code{\link{beh.test}}
#'
#' @section Data: \code{\link{cbutterfly}} \code{\link{cimmigrant}}
#'   \code{\link{cpossum}} \code{\link{ypossum}}
#'
#' @docType package
#' @name ctime
NULL
