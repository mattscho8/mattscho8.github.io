findNpost = function(N,n,t){
  lpost = lfactorial(N) - lfactorial(N-n) + (t+1)*log(1/N)
  con = max(lpost)
  post = exp(lpost - con)
  Npost = post/sum(post)
  return(Npost)
}

#' Find the Posterior Under Model Mt
#'
#' Analytically calculates the posterior distribution for the true number of
#' individuals \code{N}, assuming model Mt (equal detection probabilities).
#'
#' @param cobs A vector of counts i.e. how many times each individual was
#'   observed. This should exclude zeroes (if, for instance, we know an
#'   individual exists a priori but it is not observed).
#' @param upper The maximum value of \code{N} for which a posterior probability is
#'   calculated, i.e. where the posterior distribution is truncated. Note that
#'   this must be \strong{greater than n}, the observed number of individuals.
#' @return Returns a list of length 2 containing the posterior for \code{N}, and
#'   some summary statistics for this posterior.
#'
#' @seealso \code{\link{fitMt}}
#'
#' @examples
#' data(cbutterfly, package="ctime")   # Craig's butterfly counts (included in package)
#' result = directMt(cbutterfly)
#' plot(result$Posterior[,2], result$Posterior[,1], type="s", xlim=c(200,1700))
#' c(result$Mean, result$CI)
#' @export
directMt = function(cobs, upper=10000){
  t = sum(cobs); n = length(cobs)
  Npost = n:upper
  Ppost = lchoose(Npost, n) - (t+1)*log(Npost)
  Qpost = exp(Ppost - max(Ppost))
  Qpost = Qpost/sum(Qpost)
  postcum = cumsum(Qpost)
  if(postcum[1] > 0.025){
    Nlow = Npost[1]
  } else {
    Nlow = Npost[max(which(postcum <= 0.025))]
  }
  Nhigh = Npost[min(which(postcum >= 0.975))]
  return(list(Posterior = cbind(Qpost,Npost), Mean = sum(Qpost*Npost), SD = sqrt(sum(Qpost*(Npost-sum(Qpost*Npost))^2)), CI = c(Nlow,Nhigh)))
}
