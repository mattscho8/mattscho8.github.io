#' Catlins Possum Observations
#'
#' A vector of chronological observations of brushtail possums through fecal
#' pellets sampled in the Catlins, New Zealand.
#'
#' @format A numeric vector of length 225 (i.e. t=225).
#'
#' @seealso \code{\link{cpossum}}
#' @source Wright, J. A. (2011), "Incorporating Genotype Uncertainty Into Mark-recapture-type Models For Estimating Abundance Using DNA Samples," Ph.D. thesis, University of Otago.
"ypossum"
