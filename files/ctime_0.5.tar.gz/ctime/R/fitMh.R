
#' Estimate Posterior Densities Under Model Mh
#'
#' Use Gibbs sampling to estimate the posterior distribution for the true number
#' of individuals \code{N}, as well as posteriors for the hyperparameters for nu, denoted
#' \code{rho} and \code{pi}, under model Mh. Mh allows individual capture
#' probabilities to vary (heterogeneity).
#'
#' @param cobs A vector of counts i.e. how many times each individual was
#'   observed. This should exclude zeroes.
#' @param madapt The number of adapting iterations to use in the MCMC updater.
#' @param mkeep The number of iterations to store from the MCMC updater.
#' @param nchains The number of concurrent Markov chains to construct.
#' @param piprior The parameters for the Beta prior on pi.
#' @param rhoprior The parameter for the exponential prior on rho.
#' @param removeadapt A Boolean value. If true (the default), discard the first
#'   \code{madapt} iterations in the chain as "burn-in".
#' @param returnmcmc A Boolean value. If true (the default), the returned
#'   codafile is an mcmc list object, rather than an ordinary list.
#' @return Returns either a list or an mcmc list. Each entry in the list is a
#'   coda containing the estimated posteriors for \code{N} as well as for
#'   \code{p} and \code{a}. There is one entry for each Markov chain
#'   constructed.
#'
#' @seealso \code{\link{het.test}} \code{\link{fitMt}}
#'
#' @examples
#' data(cimmigrant, package="ctime")  # Netherlands illegal immigrant counts (included in package)
#' result1 = fitMh(cimmigrant)
#' lattice::xyplot(result1)
#' summary(result1)
#'
#' @export
fitMh = function(cobs,madapt=1000,mkeep=10000,nchains=3,piprior=c(0.001,0.001),rhoprior=-log(0.01),removeadapt=TRUE,returnmcmc=TRUE){
  t = sum(cobs)
  n = length(cobs)
  mtotal = madapt+mkeep
  store = vector('list',nchains)
  sumPi = sum(piprior)
  sigma = rep(0.01,nchains)
  Rho = runif(nchains)
  Pi = runif(nchains)
  N = rep(NA,nchains)
  for(ii in 1:nchains){
    store[[ii]] = matrix(NA,mtotal,3)
    colnames(store[[ii]]) = c('N','rho','pi')
  }
  pb <- txtProgressBar(min = 1, max = mtotal, initial = 1, char = '+', style = 3)
  for(j in 1:mtotal){
    for(ii in 1:nchains){
      N[ii] = rnbinom(1,n,1-Pi[ii]^(1/Rho[ii])) + n
      astar = rlnorm(1,log(Rho[ii]),sigma[ii])
      pstar = rbeta(1,N[ii]/astar,t+1)
      if(pstar>(1-1e-6)){
        r=0
      } else {
        r = exp(n*(lgamma(1/Rho[ii]) - lgamma(1/astar)) + sum(lgamma(cobs+1/astar)) - sum(lgamma(cobs + 1/Rho[ii])) + lgamma(N[ii]/astar + piprior[1]) - lgamma(N[ii]/Rho[ii] + piprior[1]) + lgamma(t + N[ii]/Rho[ii] + sumPi) - lgamma(t + N[ii]/astar + sumPi) + dexp(astar,rhoprior,log=TRUE) - dexp(Rho[ii],rhoprior,log=TRUE)
                + dlnorm(Rho[ii],log(astar),sigma[ii],log=TRUE) - dlnorm(astar,log(Rho[ii]),sigma[ii],log=TRUE))
      }
      u = runif(1)
      if(r>u){
        Pi[ii] = pstar
        Rho[ii] = astar
        if(j<=madapt){
          sigma[ii] = 1.05*sigma[ii]
        }
      } else {
        if(j<=madapt){
          sigma[ii] = sigma[ii]/1.05
        }
      }
      store[[ii]][j,] = c(N[ii],Rho[ii],Pi[ii])
    }
    setTxtProgressBar(pb, j)
  }
  if(removeadapt){
    for(ii in 1:nchains){
      store[[ii]] = store[[ii]][-(1:madapt),]
    }
  }
  if(returnmcmc){
    tmp = vector('list',nchains)
    for(ii in 1:nchains){
      tmp[[ii]] = coda::mcmc(store[[ii]])
    }
    return(coda::mcmc.list(tmp)) # returns an mcmc list
  } else {
    return(store) # returns ordinary list
  }
}
