#' Illegal Immigrant Apprehension Counts
#'
#' A vector of how many times individual illegal immigrants were apprehended in
#' the Netherlands.
#'
#' @format A numeric vector of length 1880 (i.e. n=1880).
#'
#' @source van der Heijden et al. (2003), "Point and interval estimation of the population size using the truncated Poisson regression model", Statistical Modelling, 3, 305-322.
"cimmigrant"
