llmb = function(pars,w){
  N = pars[1]
  phi = exp(pars[2])
  n = length(w)
  t = sum(w)+1
  R = t-n
  return(lfactorial(N) - lfactorial(N-n) - log(N) + R*log(phi) - sum(w*log(N+(1:n)*(phi-1))))
}

#' Estimate Posterior Densities Under Model Mb
#'
#' Use Gibbs sampling to estimate the posterior distributions for the true
#' number of individuals \code{N} and parameter \code{phi} under Mb. Mb allows
#' for a behavioural effect, where individuals might become more or less likely
#' to be recaptured once they are captured once. Note that this function takes
#' as input the vector of observations \code{y}, rather than the vector of
#' counts \code{c}.
#'
#' @param yobs The vector of observations - i.e. the order in which the individuals were observed.
#' @param madapt The number of adapting iterations to use in the MCMC updater.
#' @param mkeep The number of iterations to store from the MCMC updater.
#' @param nchains The number of concurrent Markov chains to construct.
#' @param phiprior The parameter for the Laplace prior on phi.
#' @param removeadapt A Boolean value. If true (the default), discard the first
#'   \code{madapt} iterations in the chain as "burn-in".
#' @param returnmcmc A Boolean value. If true (the default), the returned
#'   codafile is an mcmc list object, rather than an ordinary list.
#' @return Returns either a list or an mcmc list. Each entry in the list is a
#'   coda containing the estimated posteriors for \code{N} and \code{phi}. There
#'   is one entry for each Markov chain constructed.
#'
#' @seealso \code{\link{beh.test}} \code{\link{fitMt}}
#'
#' @examples
#' data(ypossum, package="ctime")  # Catlins possum data, included in the package
#' result = fitMb(ypossum)
#' plot(result)
#'
#' @export
fitMb = function(yobs,madapt=1000,mkeep=10000,nchains=3,phiprior=log(100)/log(3),removeadapt=TRUE,returnmcmc=TRUE){
  t = length(yobs);
  xvec = rep(0,t)
  for(j in 2:t){
    xvec[j] = length(unique(yobs[1:(j-1)]))
  }
  n = max(xvec)
  w = rep(NA,n)
  for(j in 1:n){
    w[j] = sum(xvec==j)
  }

  mtotal = madapt+mkeep
  sigma = rep(0.01,nchains)

  phi = rnorm(nchains)
  N = rpois(nchains,20)+n
  store = vector('list',nchains)
  for(ii in 1:nchains){
    store[[ii]] = matrix(NA,mtotal,2)
    colnames(store[[ii]]) = c('N','phi')
  }
  pb <- txtProgressBar(min = 1, max = mtotal, initial = 1, char = '+', style = 3)
  for(j in 1:mtotal){
    for(ii in 1:nchains){
      ## Update jointly
      Uold = N[ii] - n
      phinew = rnorm(1,phi[ii],sigma[ii])
      Unew = rnbinom(1,Uold,1/(1+exp(phinew-phi[ii])))
      lrat = exp(llmb(c(Unew+n,phinew),w)-llmb(c(N[ii],phi[ii]),w))
      prat1 = exp(dexp(abs(phinew),phiprior,log=TRUE) - dexp(abs(phi[ii]),phiprior,log=TRUE))
      prat2 = N[ii]/(Unew+n)
      jrat = exp(dnbinom(Uold,Unew,1/(1+exp(phi[ii]-phinew)),log=TRUE) - dnbinom(Unew,Uold,1/(1+exp(phinew-phi[ii])),log=TRUE))
      r = lrat*prat1*prat2*jrat

      u = runif(1)
      if(r>u){
        phi[ii] = phinew
        N[ii] = Unew + n
        if(j<=madapt){
          sigma[ii] = 1.05*sigma[ii]
        }
      } else {
        if(j<=madapt){
          sigma[ii] = sigma[ii]/1.05
        }
      }

      store[[ii]][j,] = c(N[ii],phi[ii])
    }
    setTxtProgressBar(pb, j)
  }
  if(removeadapt){
    for(ii in 1:nchains){
      store[[ii]] = store[[ii]][-(1:madapt),]
    }
  }
  if(returnmcmc){
    tmp = vector('list',nchains)
    for(ii in 1:nchains){
      tmp[[ii]] = coda::mcmc(store[[ii]])
    }
    return(coda::mcmc.list(tmp)) # returns an mcmc list
  } else {
    return(store) # returns ordinary list
  }
}
