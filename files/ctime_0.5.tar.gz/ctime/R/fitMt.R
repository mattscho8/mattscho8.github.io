
#' Estimate Posterior Densities Under Model Mt
#'
#' Use Gibbs sampling to estimate the posterior distributions for the true
#' number of individuals \code{N} and associated parameter \code{nu} under model
#' Mt. Mt assumes equal detection probabilities for all individuals. This is
#' largely a redundant function since \code{\link{directMt}} calculates the
#' posterior for \code{N} directly.
#'
#' @param cobs A vector of counts i.e. how many times each individual was
#'   observed. This should exclude zeroes.
#' @param madapt The number of adapting iterations to use in the MCMC updater.
#' @param mkeep The number of iterations to store from the MCMC updater.
#' @param nchains The number of concurrent Markov chains to construct.
#' @param nuprior The parameters for the Gamma prior on nu.
#' @param removeadapt A Boolean value. If true (the default), discard the first
#'   \code{madapt} iterations in the chain as "burn-in".
#' @param returnmcmc A Boolean value. If true (the default), the returned
#'   codafile is an mcmc list object, rather than an ordinary list.
#' @return Returns either a list or an mcmc list. Each entry in the list is a
#'   coda containing the estimated posteriors for \code{N} and\code{nu}. There
#'   is one entry for each Markov chain constructed.
#'
#' @seealso \code{\link{directMt}} \code{\link{het.test}} \code{\link{beh.test}}
#'
#' @examples
#' data(cbutterfly, package="ctime")  # Craig's butterfly counts (included in package)
#' result2 = fitMt(cbutterfly)
#' lattice::xyplot(result2)
#' summary(result2)
#'
#' @export
fitMt = function(cobs,madapt=1000,mkeep=10000,nchains=3, nuprior=c(0.001,0.001),removeadapt=TRUE,returnmcmc=TRUE){
  t = sum(cobs)
  n = length(cobs)
  mtotal = madapt+mkeep
  store = vector('list',nchains)
    nu = rgamma(nchains,1,1)
    for(ii in 1:nchains){
      store[[ii]] = matrix(NA,mtotal,2)
      colnames(store[[ii]]) = c('N','nu')
    }
    pb <- txtProgressBar(min = 1, max = mtotal, initial = 1, char = '+', style = 3)
    for(j in 1:mtotal){
      N = rnbinom(nchains,n,1-exp(-nu)) + n
      nu = rgamma(nchains,t+nuprior[1],N+nuprior[2])
      for(ii in 1:nchains){
        store[[ii]][j,] = c(N[ii],nu[ii])
      }
      setTxtProgressBar(pb, j)
    }
  if(removeadapt){
    for(ii in 1:nchains){
      store[[ii]] = store[[ii]][-(1:madapt),]
    }
  }
  if(returnmcmc){
    tmp = vector('list',nchains)
    for(ii in 1:nchains){
      tmp[[ii]] = coda::mcmc(store[[ii]])
    }
    return(coda::mcmc.list(tmp)) # returns an mcmc list
  } else {
    return(store) # returns ordinary list
  }
}
