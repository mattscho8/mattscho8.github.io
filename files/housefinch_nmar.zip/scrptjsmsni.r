model clear
data clear
model in modjsmsni.r
data in datajsmsni.r
compile, nchains(3)
parameters in initjsmsni1.r, chain(1)
parameters in initjsmsni2.r, chain(2)
parameters in initjsmsni3.r, chain(3)
initialize
adapt 25000, by(1)
monitor beta
monitor gamma
monitor sd
monitor psi
monitor zp
monitor zeta
monitor N
monitor Nd
monitor lambda
monitor delta
update 25000, by(1)
coda *, stem('CODAjsmsni')
