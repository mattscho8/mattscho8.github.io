The description of the four files:
logy.txt: this file gives the log ring-width measurements for the 247 trees across the 500 year period of interest.  The file is space delimited with each line denoting the observations from a different tree.
age.txt: this file gives the ages used for the 247 trees across the 500 year period of interest.  The file is space delimited with each line denoting the observations from a different tree.
year.txt: this file gives the calendar years corresponding to the 500 year period of interest.
temp.txt: this file gives the observed mean temperatures in Abisko for the 500 year period of interest.  The missing temperatures are denoted by NA.
