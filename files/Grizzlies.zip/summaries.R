# load('jagsout.Rdata')'
jagsfit.mcmc=as.mcmc(jagsfit)
summary(jagsfit.mcmc)  # summary statistics

# N plot
N=as.matrix(jagsfit.mcmc[,1:13])
beta=as.matrix(jagsfit.mcmc[,14:15])
nsamples=dim(beta)[1]
trend=exp(beta[,1]+matrix(beta[,2],nsamples,13)*t(matrix(cov,13,nsamples)))
qN=matrix(NA,13,5)
qtrend=matrix(NA,13,3)
for(i in 1:13)
{   qN[i,]=quantile(N[,i],c(.025,.25,.5,.75,.975))
    qtrend[i,]=quantile(trend[,i],c(.025,.5,.975))
}
yr=1986:1998
plot(yr,type="n",xlim=c(1984,2000),ylim=c(15,70),xlab="Year",ylab="Abundance",main="")
points(yr,qN[,3],pch=19)
for(i in 1:13)
{   lines(rep(yr[i],2),qN[i,c(1,5)])
    lines(rep(yr[i],2),qN[i,c(2,4)],lwd=4)
}
lines(yr,qtrend[,2],lwd=2)
lines(yr,qtrend[,1],lwd=2,lty=2)
lines(yr,qtrend[,3],lwd=2,lty=2)         
