eff=list()
eff[[1]] = c(7,5,6,1,1,0,1,2,rep(0,6),1)
eff[[2]] = c(7,3,1,1)
eff[[3]] = c(7,4,4,1,1)
eff[[4]] = c(7,5,0,1,0,0,1)
eff[[5]] = c(7,6,7,1,1)
eff[[6]] = c(11,3,3,3,1,2,1)
eff[[7]] = c(15,5,1,1,1)
eff[[8]] = c(8,8,2)
eff[[9]] = c(9,7,2)
eff[[10]] = c(13,2,1,0,1)
eff[[11]] = c(15,10,2,1)
eff[[12]] = c(13,7,4,1,3,0,1)
eff[[13]] = c(11,13,5,1,1,0,2)

### Get the individual-specific observed x matrix for each of the sampling periods.  Store in a list indexed by year.
m=length(eff)
x = list()
boycem = rep(NA,m)
boycen = rep(NA,m)
for(i in 1:m){
  k = length(eff[[i]])
  boycen[i] = sum(eff[[i]])
  boycem[i] = sum(eff[[i]]*(1:k))
  x[[i]] = matrix(0,boycen[i],boycem[i])
  countx = 1; county = 1;
  for(j in 1:k){
    if(eff[[i]][j]>0){
      for(h in 1:eff[[i]][j]){
        x[[i]][countx,county:(county+j-1)] = 1
        countx = countx + 1;
        county = county + j
      }
    }
  }
}

### Now convert the observed x's to counts of the number of times each distinct bear was seen.  Store in a list indeaxed by year.
xfull = list()
y = vector('list',m)
M = c(90,95,95,105,95,100,115,115,115,130,140,135,165)*2
for(i in 1:m){
  xfull[[i]] = rbind(x[[i]],matrix(0,M[i]-boycen[i],boycem[i]))
  y[[i]] = rep(NA,boycem[i])
  for(j in 1:boycem[i]){
    y[[i]][j] = which(x[[i]][,j]==1)
  }
}

#### Get data for mh 
maxM = max(M)
xc = vector('list',m)
xcm = matrix(NA,m,maxM)
for(i in 1:m){
  for(j in 1:length(eff[[i]])){
    xc[[i]] = c(xc[[i]],rep(j,eff[[i]][j]))
  }
  xc[[i]] = c(xc[[i]],rep(0,M[i]-boycen[i]))
  xcm[i,1:M[i]] = xc[[i]]
}

cov=((1:m)-6.5)/6
zerouse=rep(0,m)

# rename variables for assing to JAGS
x = xcm;n=boycen;nt=m