setwd('/maybehome/rbarker/Dropbox/statcollab/Manuscripts/RJvDA/Grizzlies/ForMaramatanga')
source('create.data.R')
library(R2jags)
k=20
data=c('x','M','n','nt','k','cov','zerouse')       # reads the data into an R-object called "data"

params=c('beta','sign','N','epspstore','sigp','mumup','sigmup')    # creates a string vector with the names of the parameters to keep track of
inits=function(){list('xi' = rnorm(3,sd=2),'beta'=rnorm(2,c(4,0),0.25),'taun' = rlnorm(1), 'N' = sample(max(n):min(M),m), 'epsn' = rnorm(m,0,0.25),'epsp' = rnorm(m), 'mumup' = rnorm(1), 'taup' = rlnorm(1), 'taumup' = rlnorm(1))} # creates a function that returns starting values for each of the unkown parameters in my model
jagsfit=jags(data, inits, params, n.thin=1,n.iter=5000, model.file="jagsmod.txt")
save('jagsfit',file='jagsout.Rdata') # If want to save output for later use

source('summaries.R') # create some summaries
