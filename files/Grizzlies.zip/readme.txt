1. To fit the trend model run the script file "grizzlies.jags.R" in R.  This script calls:

	(i)  create.data.R - this script takes the summary statistics in the Boyce et al. (2001) paper and creates the data in the format needed for JAGS
	(ii) summaries.R - this script summarises the output.

2. The file jagsmod.txt contains the JAGS model statement.

3.  The package R2jags must be first installed in R.
