library(rjags) # for running JAGS
library(MASS) # for boxcox
library(lattice) # for xyplot

##### CALLS IN THE TEMPERATURE DATA
xfull = c(read.table("xtorn.txt"),recursive=TRUE) 
meanx = mean(xfull,na.rm=TRUE); sdx = sd(xfull,na.rm=TRUE);
xsc = (xfull -meanx)/sdx
xuse = xsc; 

## the following code holds out values -- remove the following two lines to use all x data in reconstruction
holdind = 321:410  # the indices that we hold out
xuse[holdind] = NA ;

###### CALLS IN THE TREE RING DATA
yorig = as.matrix(read.table('ytorn.txt',header=F))

M = nrow(yorig)
Tee = ncol(yorig)

f = rep(NA,M); l = f
for(i in 1:M){
  tmp = which(!is.na(yorig[i,]))
  f[i] = min(tmp)
  l[i] = max(tmp)
}

###### CALLS IN THE AGE DATA
ause = as.matrix(read.table('age.txt',header=F))

###### CALLS IN THE YEAR DATA
year = c(read.table("year.txt"),recursive=TRUE) 


###### BOX-COX TRANSFORM -- SET UP DATA APPROPRIATELY FOR LM
firstx = min(which(!is.na(xsc)))
yvec = tvec = avec = xvec = NULL
for(i in 1:M){
  if(l[i] > (firstx + 20)){
    strt = max(f[i],firstx)
    yvec = c(yvec,yorig[i,strt:l[i]]) # ring width data
    tvec = c(tvec,rep(i,l[i]-strt+1)) # tree indicator
    avec = c(avec,ause[i,strt:l[i]]) # age variable
    xvec = c(xvec,xsc[strt:l[i]]) # temperature -- use all data
  }
}
tvec = as.factor(tvec) # turns tree indicator into a factor variable
mod = lm(yvec ~ tvec + avec + xvec + tvec*avec)
box = boxcox(mod) # the boxcox function is in the MASS package
lamuse = box$x[box$y==max(box$y)] # best lambda value
ybox = (yorig^{lamuse}-1)/lamuse # transform the data
yboxuse = (ybox - mean(ybox,na.rm = TRUE))/sd(ybox,na.rm=TRUE) # standardize the data
yuse = yboxuse
##### END OF BOX-COX

############### RUNNING THE MODELS
### In the manuscript we adapted for 10000 iterations and then sampled for a further 50000 iterations.  We have set this up here to take a
### much smaller sample by default.  
###
### In practice we may also not want to monitor all variables, or thin to ensure we do not encounter memory problems.
### We also split up the modeling of model M2 and M6 rather than fitting them sequentially.
###
### For model M2 we show limited exploration of the posterior distribution here, we:
### 1. Examine the traceplots for the gamma variables
### 2. Find summaries for the gamme variables.
### 3. Find the mean of the posterior distribution for x_{t} in each year
###
### For model M6 we show traceplots for the autocorrelation variable


##### RUNNING MODEL M2
initfunM2 = function(){ # function that generates initial values for the model
  inita0 = rnorm(M,rowMeans(yuse,na.rm=TRUE),0.25) # initial values for alpha_0 -- centered around the mean yuse value
  inita1 = -rlnorm(M,-1,0.25) # initial values for alpha_1 -- note that these must be negative
  sdy = rlnorm(M) # initial values for sigma
  mua = c(mean(inita0),mean(inita1)) # use the initial values for alpha_0 and alpha_1 to find initial value for mu_a0 and mu_a1
  sda = c(sd(inita0),sd(inita1)) # as above to find initial value for sig_a0 and sig_a1
  eta = rnorm(Tee,0,0.25) # find initial values for eta
  sdeta = sd(eta) # find initial value for sig_eta
  gamma = rnorm(2,c(0,0.4),0.1) # initial values for gamma.  The initial value for gamma 2 is set to be positive
  sdx = rlnorm(1) # initial value for sig_x
  return(list(alpha = cbind(inita0,inita1),eta = eta, mua = mua, sda = sda, sdeta = sdeta ,sdy = sdy,gamma=gamma,sdx = sdx))
}

M2 = jags.model('modM2.txt', list(y = yuse, f = f, l = l, M = M, Tee = Tee, a = ause, x=xuse), inits = initfunM2, n.chains = 3, n.adapt = 1000)
outM2 = coda.samples(M2,c('x','eta','alpha','sdy','sdeta','mua','sda','gamma','sdx'),1000)

gamidx = which(substr(varnames(outM2),1,5)=="gamma") # finds the indices of the gamma variables
xyplot(outM2[,gamidx]) # traceplot of the gamma variables
summary(outM2[,gamidx]) # summary of the gamma variables

xidx = which(substr(varnames(outM2),1,2)=="x[") # finds the indices of the x variables
postxm = colMeans(as.matrix(outM2[,xidx])) # finds the posterior mean of the x variables
plot(postxm,type="l") # plots the posterior mean of the x variables
plot(year,postxm*sdx + meanx,type="l") # plots the posterior mean of the x variables on the original scale (degrees C) and year on x-axis

##### RUNNING MODEL M6
initfunM6 = function(){ # function that generates initial values for the model
  inita0 = rnorm(M,rowMeans(yuse,na.rm=TRUE),0.25) # initial values for alpha_0 -- centered around the mean yuse value
  inita1 = -rlnorm(M,-1,0.25) # initial values for alpha_1 -- note that these must be negative
  sdy = rlnorm(M) # initial values for sigma
  mua = c(mean(inita0),mean(inita1)) # use the initial values for alpha_0 and alpha_1 to find initial value for mu_a0 and mu_a1
  sda = c(sd(inita0),sd(inita1)) # as above to find initial value for sig_a0 and sig_a1
  eta = rnorm(Tee,0,0.25) # find initial values for eta
  sdeta = sd(eta) # find initial value for sig_eta
  gamma = rnorm(2,c(0,0.4),0.1) # initial values for gamma.  The initial value for gamma 2 is set to be positive
  sdx = rlnorm(1) # initial value for sig_x
  rho = 2*rbeta(1,2,1)-1 # initial value for AR1 parameter -- "triangle"
  return(list(alpha = cbind(inita0,inita1),eta = eta, mua = mua, sda = sda, sdeta = sdeta ,sdy = sdy,gamma=gamma,sdx = sdx,rho = rho))
}

M6 = jags.model('modM6.txt', list(y = yuse, f = f, l = l, M = M, Tee = Tee, a = ause, x=xuse), inits = initfunM6, n.chains = 3, n.adapt = 1000)
outM6 = coda.samples(M6,c('x','eta','alpha','sdy','sdeta','mua','sda','gamma','sdx','rho'),1000)

rhoidx = which(substr(varnames(outM6),1,3)=="rho") # finds the indices of the gamma variables
xyplot(outM6[,rhoidx]) # traceplot of the gamma variables

