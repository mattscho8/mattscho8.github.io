Information on the files in the zip folder:

xtorn.txt is a vector that gives the observed temperature values for Tornadalen station from 1496 -- 1995.  The NA values represents years in which there was no data.

ytorn.txt has the observed ring widths (original scale) for 247 trees from Tornetrask, Northern Sweden.  Again, the NA values represents periods in which there was no data.

age.txt gives the ages of each tree in each year.  This variable has been partially centered and scaled. 

year.txt is a vector giving the year for each of the observations.

modM2.txt is a JAGS model statement for running model M2 as parameterized as (5) of the manuscript.

modM6.txt is a JAGS model statement for running model M6.  It extends model M2 through introduction of an autoregressive error structure with parameter rho.

runmod.R is a R script that fits models M2 and M6.  
Contents:
-- It calls in the data
-- It finds the optimal Box-Cox transformation
-- It fits models M2 and M6
Notes:
-- JAGS must be installed on the computer used.  
-- The packages rjags, MASS and lattice must be installed in R.
-- The code assumes that all files in the zip folder are present in the current working directory of R.  
