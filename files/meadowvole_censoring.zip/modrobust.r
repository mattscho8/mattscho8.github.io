model{
  for(i in 1:m){
    w[i] ~ dbern(pw)    
  }
  aleph <-sum(w[])
  
  for(i in 1:m) {
    for(j in 1:until[i]){
      # DEATH
      ad[i,j] ~ dbern(piad[i,j])      
      # BIRTH
      ab[i,j] ~ dbern(piab[i,j])
      # ALIVE
      a[i,j] <- ab[i,j]*ad[i,j]*w[i]      
      
      for(h in 1:k[2]){
        # CAPTURE
        x[i,j,h] ~ dbern(pcap[i,j,h])
        pcap[i,j,h]<-a[i,j]*p[i,j,h]
        
        # WEIGHT
        z[i,j,h] ~ dnorm(lambda[i,j],tauz[1])T(0,) # WITHIN SECONDARY PERIOD
      }      
      zuse[i,j] <- (lambda[i,j] - 41.9)/22.9 # 41.9 = mean of all observed z, 22.9 = 2*sd of all observed z
    }
    # FURTHER MODELING OF WEIGHT
    lambda[i,1] ~ dnorm(delta[1],tauz[2]) # INITIAL WEIGHT DISTRIBUTION
    for(j in 2:k[1]){
      lambda[i,j] ~ dnorm(mul[i,j],taul[i,j])
      mul[i,j] <- a[i,j-1]*(lambda[i,j-1]+delta[j]) + (1-a[i,j-1])*delta[1]
      taul[i,j] <- a[i,j-1]*tauz[3] + (1-a[i,j-1])*tauz[2]
#       lambda[i,j] ~ dnorm(mul[i,j],tauz[3]) # BETWEEN PRIMARY PERIODS
#       mul[i,j] <- lambda[i,j-1] + delta[j]
    }
    
    # Prob for birth
    piab[i,1] <- zeta[1]
    sazero[i,1] <- 1
    for(j in 2:until[i]){
      piab[i,j] <- sazero[i,j]*zeta[j] + (1-sazero[i,j]) # sazero takes into account whether or not born before
      sazero[i,j] <- sazero[i,j-1]*(1-ab[i,j-1])
    }
    
    # Prob for death
    piad[i,1] <- 1
    for(j in 2:until[i]){
      piad[i,j] <-   ad[i,j-1]*(ab[i,j-1]*surv[i,j-1] + (1-ab[i,j-1]))
    }
        
    for(j in 1:k[1]-1){
      logit(surv[i,j]) <- beta[1] + beta[2]*zuse[i,j] + etas[j]
    }
    for(j in 1:k[1]){
      for(h in 1:k[2]){
        logit(p[i,j,h]) <- gamma[1] + gamma[2]*zuse[i,j] + etap[j] + epsp[j,h]
      }
    }    
  }
  # Taking into account rounding of z's (and potential censoring at 60)
  for(i in 1:nc){
    zc[i] ~ dinterval(z[idx[i,1],idx[i,2],idx[i,3]],cpoint[i,1:2])
  }  
  
  for(j in 1:k[1]-1){
    etas[j] ~ dnorm(0,tau[1])      
  }
  for(j in 1:k[1]){
    etap[j] ~ dnorm(0,tau[2])
    for(h in 1:k[2]){
      epsp[j,h] ~ dnorm(0,tau[3])
    }
  }
  
  for(j in 1:k[1]-1){
    zeta[j] ~ dbeta(1,uppz[j])
    uppz[j] <- k[1]-j
  }  
  zeta[k[1]] <- 1
    
  pw ~ dbeta(1,1)
  
  for(j in 1:k[1]){
    N[j]<-sum(a[1:m,j]) 
    delta[j] ~ dnorm(0,0.0001)
  }
    
  for(h in 1:3){
    tau[h] <- 1/sd[h]/sd[h]
    sd[h] ~ dt(0,0.04,3)T(0,)    
    tauz[h] <- 1/sdz[h]/sdz[h]
    sdz[h] ~ dt(0,0.04,3)T(0,) 
  }
  for(j in 1:2){
    gamma[j] ~ dt(0,0.16,3)
    beta[j] ~ dt(0,0.16,3)    
  }  
}
