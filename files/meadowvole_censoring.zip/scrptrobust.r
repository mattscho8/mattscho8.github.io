model clear
data clear
model in modrobust.r
data in datarobust.r
compile, nchains(3)
parameters in initrobust1.r, chain(1)
parameters in initrobust2.r, chain(2)
parameters in initrobust3.r, chain(3)
initialize
adapt 5000, by(2)
monitor beta
monitor gamma
monitor delta
monitor sd
monitor sdz
monitor N
monitor zeta
monitor aleph
monitor z[3,1,1]
monitor z[12,1,1]
update 20000, by(2)
coda *, stem('CODArobust')
exit
