model clear
data clear
model in modrobustraw.r
data in datarobustraw.r
compile, nchains(3)
parameters in initrobustraw1.r, chain(1)
parameters in initrobustraw2.r, chain(2)
parameters in initrobustraw3.r, chain(3)
initialize
adapt 5000, by(2)
monitor beta
monitor gamma
monitor delta
monitor sd
monitor sdz
monitor N
monitor zeta
monitor aleph
monitor z[3,1,1]
monitor z[12,1,1]
update 20000, by(2)
coda *, stem('CODArobustraw')
exit
